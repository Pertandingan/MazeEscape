import { Canvas } from "@react-three/fiber";
import { Suspense, useState } from "react";
import { KeyboardControls } from "@react-three/drei";
import { useGame } from "./lib/stores/useGame";
import Menu from "./components/Menu";
import LevelSelect from "./components/LevelSelect";
import HowToPlay from "./components/HowToPlay";
import Credits from "./components/Credits";
import GameOver from "./components/GameOver";
import Game3D from "./components/Game3D";
import GameUI from "./components/GameUI";
import ClickToPlayOverlay from "./components/ClickToPlayOverlay";
import FreezePowerUI from "./components/FreezePowerUI";
import "@fontsource/inter";

// Define control keys for the game
const controls = [
  { name: "forward", keys: ["KeyW"] },
  { name: "backward", keys: ["KeyS"] },
  { name: "leftward", keys: ["KeyA"] },
  { name: "rightward", keys: ["KeyD"] },
  { name: "turnLeft", keys: ["ArrowLeft"] },
  { name: "turnRight", keys: ["ArrowRight"] },
  { name: "jump", keys: ["Space"] },
  { name: "pause", keys: ["KeyP"] },
  { name: "reset", keys: ["KeyR"] },
];

function App() {
  const { gameState } = useGame();

  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative', overflow: 'hidden' }}>
      <KeyboardControls map={controls}>
        {gameState === 'menu' && <Menu />}
        {gameState === 'levelSelect' && <LevelSelect />}
        {gameState === 'howToPlay' && <HowToPlay />}
        {gameState === 'credits' && <Credits />}
        {gameState === 'gameOver' && <GameOver />}
        {gameState === 'playing' && (
          <>
            <Canvas
              shadows
              camera={{
                position: [1, 0.6, 1],
                fov: 75,
                near: 0.1,
                far: 100
              }}
              gl={{
                antialias: true,
                powerPreference: "high-performance"
              }}
              style={{ width: '100%', height: '100%' }}
              onCreated={({ gl }) => {
                gl.domElement.addEventListener('click', () => {
                  gl.domElement.requestPointerLock();
                });
              }}
            >
              <color attach="background" args={["#0a0a0a"]} />
              <Suspense fallback={null}>
                <Game3D />
              </Suspense>
            </Canvas>
            <GameUI />
            <FreezePowerUI />
            <ClickToPlayOverlay />
          </>
        )}
      </KeyboardControls>
    </div>
  );
}

export default App;
