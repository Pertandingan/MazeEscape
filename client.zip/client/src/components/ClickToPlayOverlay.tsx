import { useState, useEffect } from 'react';

export default function ClickToPlayOverlay() {
  const [isVisible, setIsVisible] = useState(true);
  const [pointerLocked, setPointerLocked] = useState(false);

  useEffect(() => {
    const handlePointerLockChange = () => {
      const locked = !!document.pointerLockElement;
      setPointerLocked(locked);
      if (locked) {
        setIsVisible(false);
      }
    };

    document.addEventListener('pointerlockchange', handlePointerLockChange);
    return () => document.removeEventListener('pointerlockchange', handlePointerLockChange);
  }, []);

  const handleClick = () => {
    const canvas = document.querySelector('canvas');
    if (canvas) {
      canvas.requestPointerLock();
    }
  };

  if (!isVisible || pointerLocked) {
    return null;
  }

  return (
    <div 
      className="click-to-play"
      onClick={handleClick}
    >
      🎮 Click to Start Playing
      <br />
      <small>WASD = Move • Arrow Keys = Look Around</small>
    </div>
  );
}