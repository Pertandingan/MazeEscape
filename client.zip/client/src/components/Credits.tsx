import { useGame } from '../lib/stores/useGame';

export default function Credits() {
  const { setGameState } = useGame();

  return (
    <div className="how-to-play-container">
      <button 
        className="back-btn"
        onClick={() => setGameState('menu')}
      >
        ← Back to Menu
      </button>
      
      <div className="how-to-play-content">
        <h1 className="how-to-play-title">Credits</h1>
        
        <div className="instructions-grid">
          <div className="instruction-section">
            <h2>Game Developer</h2>
            <p>This amazing 3D Maze Escape game was created by <strong>Zachary Roubidioux</strong>!</p>
            <p>Zachary designed and built this thrilling first-person maze adventure with monsters, multiple levels, and an immersive 3D experience.</p>
          </div>

          <div className="instruction-section">
            <h2>Game Features</h2>
            <ul>
              <li>8 challenging levels with increasing difficulty</li>
              <li>Smart AI monsters that chase you through the maze</li>
              <li>First-person perspective with mouse controls</li>
              <li>Complete menu system and user interface</li>
              <li>Fullscreen support for immersive gameplay</li>
            </ul>
          </div>

          <div className="instruction-section">
            <h2>Technologies Used</h2>
            <ul>
              <li>React & TypeScript for the user interface</li>
              <li>Three.js for 3D graphics and rendering</li>
              <li>WebGL for hardware-accelerated graphics</li>
              <li>HTML5 Canvas for game rendering</li>
              <li>CSS3 for beautiful animations and styling</li>
            </ul>
          </div>

          <div className="instruction-section">
            <h2>Special Thanks</h2>
            <p>Thank you Zachary for creating this incredible gaming experience! Your vision brought this 3D maze adventure to life.</p>
            <p>Players around the world will enjoy the challenge and excitement you've built into every level.</p>
          </div>
        </div>

        <button 
          className="play-btn"
          onClick={() => setGameState('menu')}
        >
          Back to Main Menu
        </button>
      </div>
    </div>
  );
}