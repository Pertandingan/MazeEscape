import { useGame } from '../lib/stores/useGame';

export default function FreezePowerUI() {
  const { freezePowerCooldown, monstersFrozen } = useGame();
  const isReady = freezePowerCooldown <= 0;
  
  return (
    <div className="freeze-power-ui">
      <div className={`power-button ${isReady ? 'ready' : 'cooldown'} ${monstersFrozen ? 'active' : ''}`}>
        <span className="power-icon">❄️</span>
        <span className="power-label">FREEZE</span>
        {!isReady && (
          <span className="cooldown-text">{Math.ceil(freezePowerCooldown)}s</span>
        )}
        {monstersFrozen && (
          <span className="active-text">ACTIVE</span>
        )}
      </div>
      <div className="power-hint">
        Press SPACEBAR to freeze monsters for 3 seconds
      </div>
    </div>
  );
}