import { useRef, useEffect, useState } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { useKeyboardControls, OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import { useGame } from '../lib/stores/useGame';
import Player from './Player';
import Monster from './Monster';
import Maze3D from './Maze3D';
import Lighting from './Lighting';

export default function Game3D() {
  const { 
    currentLevel, 
    setCurrentLevel, 
    setGameState, 
    freezePowerCooldown, 
    monstersFrozen, 
    setFreezePowerCooldown, 
    setMonstersFrozen 
  } = useGame();
  const [maze, setMaze] = useState<number[][]>([]);
  const [playerPosition, setPlayerPosition] = useState<[number, number, number]>([1, 0, 1]);
  const [playerDirection, setPlayerDirection] = useState(0); // Rotation in radians
  const [monsters, setMonsters] = useState<Array<{ id: number; position: [number, number, number] }>>([]);
  const [goalPosition, setGoalPosition] = useState<[number, number, number]>([0, 0, 0]);
  
  // Direct keyboard state tracking
  const [keys, setKeys] = useState({
    w: false,
    a: false,
    s: false,
    d: false,
    arrowLeft: false,
    arrowRight: false
  });
  
  const cameraRef = useRef<THREE.Camera>();
  const { camera } = useThree();

  // Direct keyboard event handling
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      if (['w', 'a', 's', 'd'].includes(key)) {
        setKeys(prev => ({ ...prev, [key]: true }));
        console.log(`Key DOWN: ${key.toUpperCase()}`);
      }
      if (e.key === 'ArrowLeft') {
        setKeys(prev => ({ ...prev, arrowLeft: true }));
        console.log('Arrow LEFT DOWN');
      }
      if (e.key === 'ArrowRight') {
        setKeys(prev => ({ ...prev, arrowRight: true }));
        console.log('Arrow RIGHT DOWN');
      }
      if (e.key === ' ') { // Spacebar for freeze power
        if (freezePowerCooldown <= 0) {
          setMonstersFrozen(true);
          setFreezePowerCooldown(10); // 10 second cooldown
          console.log('Freeze power activated!');
          
          // Unfreeze after 3 seconds
          setTimeout(() => {
            setMonstersFrozen(false);
            console.log('Monsters unfrozen');
          }, 3000);
        }
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      if (['w', 'a', 's', 'd'].includes(key)) {
        setKeys(prev => ({ ...prev, [key]: false }));
        console.log(`Key UP: ${key.toUpperCase()}`);
      }
      if (e.key === 'ArrowLeft') {
        setKeys(prev => ({ ...prev, arrowLeft: false }));
        console.log('Arrow LEFT UP');
      }
      if (e.key === 'ArrowRight') {
        setKeys(prev => ({ ...prev, arrowRight: false }));
        console.log('Arrow RIGHT UP');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // Removed mouse movement tracking - using arrow keys instead

  // Generate maze based on current level
  useEffect(() => {
    console.log('Generating maze for level:', currentLevel);
    generateMaze(currentLevel);
  }, [currentLevel]);

  const generateMaze = (level: number) => {
    console.log(`Generating maze for level ${level}`);
    
    // Calculate maze size based on level
    const baseSize = 15 + Math.floor(level / 2) * 4;
    const size = Math.min(baseSize, 35);
    
    // Create maze using recursive backtracking
    const newMaze = Array(size).fill(null).map(() => Array(size).fill(1));
    
    // Generate paths
    generateMazePaths(newMaze, 1, 1, size);
    
    // Set start and goal
    newMaze[1][1] = 0; // Start
    newMaze[size - 2][size - 2] = 0; // Goal
    
    setMaze(newMaze);
    setPlayerPosition([1.5, 0, 1.5]); // Start in center of cell
    setGoalPosition([size - 1.5, 0, size - 1.5]);
    
    // Generate monsters based on level
    const monsterCount = Math.min(level, 10);
    const newMonsters = [];
    
    for (let i = 0; i < monsterCount; i++) {
      let monsterX, monsterZ;
      do {
        monsterX = Math.floor(Math.random() * (size - 2)) + 1;
        monsterZ = Math.floor(Math.random() * (size - 2)) + 1;
      } while (
        newMaze[monsterZ][monsterX] === 1 || 
        (monsterX === 1 && monsterZ === 1) ||
        (monsterX === size - 2 && monsterZ === size - 2)
      );
      
      newMonsters.push({
        id: i,
        position: [monsterX + 0.5, 0.5, monsterZ + 0.5] as [number, number, number]
      });
    }
    
    setMonsters(newMonsters);
  };

  const generateMazePaths = (maze: number[][], x: number, z: number, size: number) => {
    maze[z][x] = 0;
    
    const directions = [
      [0, -2], [2, 0], [0, 2], [-2, 0]
    ];
    
    // Shuffle directions
    for (let i = directions.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [directions[i], directions[j]] = [directions[j], directions[i]];
    }
    
    for (const [dx, dz] of directions) {
      const newX = x + dx;
      const newZ = z + dz;
      
      if (newX > 0 && newX < size - 1 && 
          newZ > 0 && newZ < size - 1 && 
          maze[newZ][newX] === 1) {
        
        maze[z + dz/2][x + dx/2] = 0;
        generateMazePaths(maze, newX, newZ, size);
      }
    }
  };

  // Handle movement and camera with new direct input system
  useFrame(() => {
    if (!camera || !maze.length) return;
    
    let [px, py, pz] = playerPosition;
    let direction = playerDirection;
    let newX = px;
    let newZ = pz;

    // Arrow key turning - fixed inverted controls
    const turnSpeed = 0.05;
    if (keys.arrowLeft) {
      direction += turnSpeed;
      setPlayerDirection(direction);
      console.log('Turning LEFT with arrow key');
    }
    if (keys.arrowRight) {
      direction -= turnSpeed;
      setPlayerDirection(direction);
      console.log('Turning RIGHT with arrow key');
    }

    const moveSpeed = 0.1;

    // Correct WASD movement - standard first-person controls
    if (keys.w) {
      newX += Math.sin(direction) * moveSpeed; // Forward
      newZ += Math.cos(direction) * moveSpeed;
      console.log('Moving FORWARD with W key');
    }
    if (keys.s) {
      newX -= Math.sin(direction) * moveSpeed; // Backward
      newZ -= Math.cos(direction) * moveSpeed;
      console.log('Moving BACKWARD with S key');
    }
    if (keys.a) {
      newX += Math.cos(direction) * moveSpeed; // Strafe left
      newZ -= Math.sin(direction) * moveSpeed;
      console.log('Moving LEFT with A key');
    }
    if (keys.d) {
      newX -= Math.cos(direction) * moveSpeed; // Strafe right
      newZ += Math.sin(direction) * moveSpeed;
      console.log('Moving RIGHT with D key');
    }
    
    // Debug current state
    if (keys.w || keys.a || keys.s || keys.d) {
      console.log('ACTIVE KEYS:', keys);
      console.log('Current position:', px.toFixed(2), pz.toFixed(2));
      console.log('New position:', newX.toFixed(2), newZ.toFixed(2));
    }

    // Improved collision detection with smaller margin to prevent wall clipping
    const margin = 0.25;
    let finalX = px;
    let finalZ = pz;
    
    // Helper function to check if position is valid
    const isValidPosition = (x: number, z: number) => {
      const gridX = Math.floor(x);
      const gridZ = Math.floor(z);
      return gridX >= 0 && gridX < maze[0].length && 
             gridZ >= 0 && gridZ < maze.length && 
             maze[gridZ][gridX] === 0;
    };
    
    // Test X movement independently
    if (Math.abs(newX - px) > 0.001) {
      const testCorners = [
        [newX - margin, pz - margin],
        [newX + margin, pz - margin],
        [newX - margin, pz + margin],
        [newX + margin, pz + margin]
      ];
      
      let canMoveX = testCorners.every(([x, z]) => isValidPosition(x, z));
      if (canMoveX) {
        finalX = newX;
      } else {
        console.log('X movement blocked at', newX.toFixed(2));
      }
    }
    
    // Test Z movement independently  
    if (Math.abs(newZ - pz) > 0.001) {
      const testCorners = [
        [finalX - margin, newZ - margin],
        [finalX + margin, newZ - margin],
        [finalX - margin, newZ + margin],
        [finalX + margin, newZ + margin]
      ];
      
      let canMoveZ = testCorners.every(([x, z]) => isValidPosition(x, z));
      if (canMoveZ) {
        finalZ = newZ;
      } else {
        console.log('Z movement blocked at', newZ.toFixed(2));
      }
    }
    
    setPlayerPosition([finalX, py, finalZ]);

    // Third-person camera following player
    const cameraHeight = 3; // Higher camera for third-person view
    const cameraDistance = 4; // Distance behind player
    
    // Calculate camera position behind and above player
    const cameraX = finalX - Math.sin(direction) * cameraDistance;
    const cameraZ = finalZ - Math.cos(direction) * cameraDistance;
    
    camera.position.set(cameraX, py + cameraHeight, cameraZ);
    
    // Camera looks at the player
    camera.lookAt(finalX, py + 1, finalZ);

    // Check win condition
    const goalDistance = Math.sqrt(
      Math.pow(finalX - goalPosition[0], 2) + 
      Math.pow(finalZ - goalPosition[2], 2)
    );
    
    if (goalDistance < 1.0) {
      console.log("Level completed! Moving to next level...");
      // Handle level completion - advance to next level
      const nextLevel = currentLevel + 1;
      if (nextLevel <= 8) {
        setCurrentLevel(nextLevel);
      } else {
        console.log("All levels completed!");
        setGameState('menu');
      }
    }
    
    // Check monster collision - using current monster positions
    for (const monster of monsters) {
      const monsterDistance = Math.sqrt(
        Math.pow(finalX - monster.position[0], 2) + 
        Math.pow(finalZ - monster.position[2], 2)
      );
      
      if (monsterDistance < 0.6) {
        console.log("Caught by monster! Game Over!");
        setGameState('gameOver');
        return; // Stop processing immediately
      }
    }
    
    // Update cooldown timer
    if (freezePowerCooldown > 0) {
      setFreezePowerCooldown(Math.max(0, freezePowerCooldown - 1/60)); // Decrease by 1/60 per frame
    }
  });

  if (!maze.length) return null;

  // Debug maze state
  console.log('Maze length:', maze.length);
  console.log('Player position:', playerPosition);
  console.log('Camera position:', camera.position);

  return (
    <>
      {/* Sky background */}
      <color attach="background" args={["#87CEEB"]} />
      
      <Lighting />
      
      {/* TEST CUBE - Should always be visible */}
      <mesh position={[5, 1, 5]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color="#ff0000" emissive="#ff0000" emissiveIntensity={0.3} />
      </mesh>
      
      {/* Generate maze walls */}
      <Maze3D maze={maze} />
      

      
      {/* Monsters */}
      {monsters.map((monster) => (
        <Monster
          key={monster.id}
          position={monster.position}
          targetPosition={playerPosition}
          maze={maze}
          frozen={monstersFrozen}
        />
      ))}
      
      {/* Goal - bright spinning beacon */}
      <mesh position={goalPosition}>
        <boxGeometry args={[0.8, 3, 0.8]} />
        <meshStandardMaterial 
          color="#ffff00" 
          emissive="#ffff00" 
          emissiveIntensity={0.8}
        />
      </mesh>
      
      {/* Goal glow effect */}
      <pointLight
        position={goalPosition}
        intensity={2.0}
        distance={10}
        color="#ffff00"
      />
      <mesh position={goalPosition}>
        <cylinderGeometry args={[0.4, 0.4, 1]} />
        <meshStandardMaterial 
          color="#ffd700" 
          emissive="#ffaa00" 
          emissiveIntensity={0.5}
        />
      </mesh>
      
      {/* Ground plane */}
      <mesh position={[maze[0].length / 2, -0.1, maze.length / 2]} receiveShadow rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[maze[0].length * 2, maze.length * 2]} />
        <meshStandardMaterial color="#1a1a1a" />
      </mesh>
      {/* Player Character */}
      <Player position={playerPosition} direction={playerDirection} />
    </>
  );
}