import { useGame } from '../lib/stores/useGame';

export default function GameOver() {
  const { setGameState, currentLevel, setCurrentLevel } = useGame();

  const handleRetry = () => {
    setGameState('playing');
  };

  const handleMainMenu = () => {
    setGameState('menu');
  };

  return (
    <div className="game-over-container">
      <div className="game-over-content">
        <h1 className="game-over-title">GAME OVER</h1>
        
        <div className="game-over-message">
          <p>You were caught by a monster!</p>
          <p>Level {currentLevel} was too challenging this time.</p>
        </div>

        <div className="game-over-stats">
          <div className="stat-item">
            <span className="stat-label">Level Reached:</span>
            <span className="stat-value">{currentLevel}</span>
          </div>
        </div>

        <div className="game-over-buttons">
          <button 
            className="retry-btn"
            onClick={handleRetry}
          >
            🔄 TRY AGAIN
          </button>
          
          <button 
            className="menu-btn"
            onClick={handleMainMenu}
          >
            🏠 MAIN MENU
          </button>
        </div>

        <div className="game-over-tips">
          <h3>💡 Tips for Next Time:</h3>
          <ul>
            <li>Move carefully around corners</li>
            <li>Listen for monster movements</li>
            <li>Plan your route to the goal</li>
            <li>Use walls to break line of sight</li>
          </ul>
        </div>
      </div>
      
      {/* Animated background */}
      <div className="game-over-bg">
        <div className="bg-particles">
          {Array.from({ length: 15 }).map((_, i) => (
            <div key={i} className="particle red" style={{
              '--delay': `${i * 0.3}s`,
              '--x': `${Math.random() * 100}%`,
              '--y': `${Math.random() * 100}%`
            } as React.CSSProperties} />
          ))}
        </div>
      </div>
    </div>
  );
}