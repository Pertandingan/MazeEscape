import { useState, useEffect } from 'react';
import { useGame } from '../lib/stores/useGame';

export default function GameUI() {
  const { gameState, currentLevel, setGameState, resetLevel } = useGame();
  const [time, setTime] = useState(0);
  const [score, setScore] = useState(0);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    if (gameState === 'playing' && !paused) {
      const interval = setInterval(() => {
        setTime(prev => prev + 1);
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [gameState, paused]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handlePause = () => {
    setPaused(!paused);
  };

  const handleReset = () => {
    setTime(0);
    resetLevel();
  };

  const handleMainMenu = () => {
    setTime(0);
    setGameState('menu');
  };

  const handleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(err => {
        console.log("Fullscreen not supported:", err);
      });
    } else {
      document.exitFullscreen();
    }
  };

  if (gameState !== 'playing') return null;

  return (
    <>
      {/* Top HUD */}
      <div className="game-hud">
        <div className="hud-left">
          <div className="hud-item">
            <span className="hud-label">LEVEL</span>
            <span className="hud-value">{currentLevel}</span>
          </div>
          <div className="hud-item">
            <span className="hud-label">TIME</span>
            <span className="hud-value">{formatTime(time)}</span>
          </div>
          <div className="hud-item">
            <span className="hud-label">SCORE</span>
            <span className="hud-value">{score.toLocaleString()}</span>
          </div>
        </div>
        
        <div className="hud-right">
          <button className="hud-btn" onClick={handlePause}>
            {paused ? '▶️' : '⏸️'}
          </button>
          <button className="hud-btn" onClick={handleReset}>
            🔄
          </button>
          <button className="hud-btn" onClick={handleFullscreen}>
            ⛶
          </button>
          <button className="hud-btn" onClick={handleMainMenu}>
            🏠
          </button>
        </div>
      </div>

      {/* Mobile controls */}
      <div className="mobile-controls">
        <div className="control-pad">
          <button className="control-btn up">↑</button>
          <div className="control-row">
            <button className="control-btn left">←</button>
            <button className="control-btn jump">JUMP</button>
            <button className="control-btn right">→</button>
          </div>
          <button className="control-btn down">↓</button>
        </div>
      </div>

      {/* Pause overlay */}
      {paused && (
        <div className="pause-overlay">
          <div className="pause-content">
            <h2>GAME PAUSED</h2>
            <div className="pause-buttons">
              <button className="pause-btn" onClick={handlePause}>
                RESUME
              </button>
              <button className="pause-btn" onClick={handleReset}>
                RESTART LEVEL
              </button>
              <button className="pause-btn" onClick={handleMainMenu}>
                MAIN MENU
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Minimap */}
      <div className="minimap">
        <div className="minimap-title">MAP</div>
        <div className="minimap-content">
          {/* Minimap will be rendered here */}
        </div>
      </div>
    </>
  );
}