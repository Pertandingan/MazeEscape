import { useGame } from '../lib/stores/useGame';

export default function HowToPlay() {
  const { setGameState } = useGame();

  return (
    <div className="how-to-play-container">
      <div className="how-to-play-content">
        <h1 className="how-to-play-title">HOW TO PLAY</h1>
        
        <button 
          className="back-btn"
          onClick={() => setGameState('menu')}
        >
          ← BACK TO MENU
        </button>
        
        <div className="instructions-grid">
          <div className="instruction-section">
            <h2>🎯 OBJECTIVE</h2>
            <p>Navigate through the 3D maze to reach the golden goal while avoiding monsters that chase you!</p>
          </div>
          
          <div className="instruction-section">
            <h2>🎮 CONTROLS</h2>
            <div className="controls-list">
              <div className="control-item">
                <span className="key">W A S D</span>
                <span>Move around</span>
              </div>
              <div className="control-item">
                <span className="key">← →</span>
                <span>Turn left/right</span>
              </div>
              <div className="control-item">
                <span className="key">SPACE</span>
                <span>Jump over walls</span>
              </div>
              <div className="control-item">
                <span className="key">P</span>
                <span>Pause game</span>
              </div>
              <div className="control-item">
                <span className="key">R</span>
                <span>Reset level</span>
              </div>
            </div>
          </div>
          
          <div className="instruction-section">
            <h2>👹 MONSTERS</h2>
            <p>Red monsters will chase you through the maze. They get faster and smarter as levels progress. Avoid them at all costs!</p>
          </div>
          
          <div className="instruction-section">
            <h2>🏆 SCORING</h2>
            <p>Complete levels quickly to earn higher scores. Each level has increasing difficulty with more monsters and larger mazes.</p>
          </div>
          
          <div className="instruction-section">
            <h2>💡 TIPS</h2>
            <ul>
              <li>Use jumping to take shortcuts over walls</li>
              <li>Listen for monster sounds to know when they're near</li>
              <li>Plan your route before moving</li>
              <li>Use corners to break line of sight with monsters</li>
            </ul>
          </div>
        </div>
        
        <button 
          className="play-btn"
          onClick={() => setGameState('levelSelect')}
        >
          START PLAYING →
        </button>
      </div>
    </div>
  );
}