import { useGame } from '../lib/stores/useGame';

const LEVELS = [
  { id: 1, name: "Beginner's Maze", difficulty: "Easy", size: "Small", monsters: 1 },
  { id: 2, name: "Garden Path", difficulty: "Easy", size: "Small", monsters: 2 },
  { id: 3, name: "Twisted Corridors", difficulty: "Medium", size: "Medium", monsters: 3 },
  { id: 4, name: "Monster's Den", difficulty: "Medium", size: "Medium", monsters: 4 },
  { id: 5, name: "Labyrinth of Shadows", difficulty: "Hard", size: "Large", monsters: 5 },
  { id: 6, name: "Nightmare Maze", difficulty: "Hard", size: "Large", monsters: 6 },
  { id: 7, name: "Infinite Depths", difficulty: "Expert", size: "Huge", monsters: 8 },
  { id: 8, name: "Hell's Gateway", difficulty: "Expert", size: "Huge", monsters: 10 },
];

export default function LevelSelect() {
  const { setGameState, setCurrentLevel } = useGame();

  const handleLevelSelect = (levelId: number) => {
    setCurrentLevel(levelId);
    setGameState('playing');
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return '#4ade80';
      case 'Medium': return '#fbbf24';
      case 'Hard': return '#f87171';
      case 'Expert': return '#a855f7';
      default: return '#6b7280';
    }
  };

  return (
    <div className="level-select-container">
      <div className="level-select-content">
        <h1 className="level-title">SELECT LEVEL</h1>
        
        <button 
          className="back-btn"
          onClick={() => setGameState('menu')}
        >
          ← BACK TO MENU
        </button>
        
        <div className="levels-grid">
          {LEVELS.map((level) => (
            <div 
              key={level.id}
              className="level-card"
              onClick={() => handleLevelSelect(level.id)}
            >
              <div className="level-number">{level.id}</div>
              <h3 className="level-name">{level.name}</h3>
              <div className="level-details">
                <div 
                  className="difficulty-badge"
                  style={{ backgroundColor: getDifficultyColor(level.difficulty) }}
                >
                  {level.difficulty}
                </div>
                <div className="level-info">
                  <span>Size: {level.size}</span>
                  <span>Monsters: {level.monsters}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}