export default function Lighting() {
  return (
    <>
      {/* Ambient light for overall illumination - MUCH BRIGHTER */}
      <ambientLight intensity={1.5} color="#ffffff" />
      
      {/* Main directional light (sun) - BRIGHTER */}
      <directionalLight
        position={[10, 20, 5]}
        intensity={2.0}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-far={50}
        shadow-camera-left={-20}
        shadow-camera-right={20}
        shadow-camera-top={20}
        shadow-camera-bottom={-20}
        color="#ffffff"
      />
      
      {/* Fill light from the opposite side */}
      <directionalLight
        position={[-5, 10, -5]}
        intensity={0.3}
        color="#8888ff"
      />
      
      {/* Rim light for dramatic effect */}
      <directionalLight
        position={[0, 5, -20]}
        intensity={0.2}
        color="#ff8888"
      />
      
      {/* Multiple point lights for better maze illumination */}
      <pointLight
        position={[5, 6, 5]}
        intensity={1.0}
        distance={15}
        decay={2}
        color="#ffaa44"
      />
      <pointLight
        position={[15, 6, 15]}
        intensity={1.0}
        distance={15}
        decay={2}
        color="#44aaff"
      />
      <pointLight
        position={[10, 6, 25]}
        intensity={1.0}
        distance={15}
        decay={2}
        color="#ff44aa"
      />
    </>
  );
}