import { useMemo } from 'react';
import * as THREE from 'three';

interface Maze3DProps {
  maze: number[][];
}

export default function Maze3D({ maze }: Maze3DProps) {
  const walls = useMemo(() => {
    const wallElements: JSX.Element[] = [];
    
    for (let z = 0; z < maze.length; z++) {
      for (let x = 0; x < maze[z].length; x++) {
        if (maze[z][x] === 1) {
          wallElements.push(
            <mesh 
              key={`wall-${x}-${z}`}
              position={[x, 1, z]} 
              castShadow 
              receiveShadow
            >
              <boxGeometry args={[1, 2, 1]} />
              <meshStandardMaterial 
                color="#222222"
                roughness={0.8}
                metalness={0.1}
              />
            </mesh>
          );
        }
      }
    }
    
    return wallElements;
  }, [maze]);

  // Create floor tiles
  const floors = useMemo(() => {
    const floorElements: JSX.Element[] = [];
    
    for (let z = 0; z < maze.length; z++) {
      for (let x = 0; x < maze[z].length; x++) {
        if (maze[z][x] === 0) {
          floorElements.push(
            <mesh 
              key={`floor-${x}-${z}`}
              position={[x, 0, z]} 
              receiveShadow
              rotation={[-Math.PI / 2, 0, 0]}
            >
              <planeGeometry args={[1, 1]} />
              <meshStandardMaterial 
                color="#228822"
                roughness={0.9}
                metalness={0.0}
                emissive="#004400"
                emissiveIntensity={0.2}
              />
            </mesh>
          );
        }
      }
    }
    
    return floorElements;
  }, [maze]);

  return (
    <group>
      {walls}
      {floors}
    </group>
  );
}