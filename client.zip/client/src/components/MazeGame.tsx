import { useEffect, useRef } from 'react';

class MazeGameEngine {
    private canvas: HTMLCanvasElement;
    private ctx: CanvasRenderingContext2D;
    
    // Game state
    private level: number = 1;
    private maxLevel: number = 10;
    private paused: boolean = false;
    private gameStartTime: number = 0;
    private levelStartTime: number = 0;
    private animationId: number | null = null;
    
    // Player
    private player = { x: 1, y: 1 };
    private playerSize = 0.8; // Size relative to tile
    
    // Maze
    private maze: number[][] = [];
    private tileSize = 40;
    private mazeWidth = 0;
    private mazeHeight = 0;
    
    // Animation
    private playerOffset = { x: 0, y: 0 };
    private animationProgress = 0;
    private isAnimating = false;
    
    // Particle effects
    private particles: any[] = [];

    constructor(canvas: HTMLCanvasElement) {
        this.canvas = canvas;
        const ctx = canvas.getContext("2d");
        if (!ctx) throw new Error("Canvas context not available");
        this.ctx = ctx;
        
        this.initEventListeners();
        this.startGame();
    }
    
    private initEventListeners() {
        // Keyboard controls
        document.addEventListener("keydown", (e) => this.handleKeyDown(e));
        
        // Button controls
        const fullscreenBtn = document.getElementById("fullscreenBtn");
        const resetBtn = document.getElementById("resetBtn");
        const pauseBtn = document.getElementById("pauseBtn");
        const playAgainBtn = document.getElementById("playAgainBtn");
        
        fullscreenBtn?.addEventListener("click", () => this.toggleFullscreen());
        resetBtn?.addEventListener("click", () => this.resetLevel());
        pauseBtn?.addEventListener("click", () => this.togglePause());
        playAgainBtn?.addEventListener("click", () => this.restartGame());
        
        // Prevent context menu on canvas
        this.canvas.addEventListener("contextmenu", (e) => e.preventDefault());
        
        // Handle window resize
        window.addEventListener("resize", () => this.handleResize());
    }
    
    private handleKeyDown(e: KeyboardEvent) {
        if (this.paused && e.key.toLowerCase() !== 'p') return;
        
        switch(e.key.toLowerCase()) {
            case 'arrowup':
            case 'w':
                e.preventDefault();
                this.movePlayer(0, -1);
                break;
            case 'arrowdown':
            case 's':
                e.preventDefault();
                this.movePlayer(0, 1);
                break;
            case 'arrowleft':
            case 'a':
                e.preventDefault();
                this.movePlayer(-1, 0);
                break;
            case 'arrowright':
            case 'd':
                e.preventDefault();
                this.movePlayer(1, 0);
                break;
            case 'p':
                e.preventDefault();
                this.togglePause();
                break;
            case 'r':
                e.preventDefault();
                this.resetLevel();
                break;
            case 'f':
                e.preventDefault();
                this.toggleFullscreen();
                break;
        }
    }
    
    private generateMaze(level: number) {
        // Calculate maze size based on level
        const baseSize = 15;
        const sizeIncrease = Math.floor(level / 2) * 2;
        const size = Math.min(baseSize + sizeIncrease, 35);
        
        this.mazeWidth = size;
        this.mazeHeight = size;
        
        // Initialize maze with walls
        this.maze = Array(size).fill(null).map(() => Array(size).fill(1));
        
        // Generate maze using recursive backtracking
        this.generateMazeRecursive(1, 1);
        
        // Ensure start and end are clear
        this.maze[1][1] = 0;
        this.maze[size - 2][size - 2] = 0;
        
        // Create some additional paths for easier navigation
        this.createAdditionalPaths();
        
        // Calculate tile size to fit canvas
        this.calculateTileSize();
    }
    
    private generateMazeRecursive(x: number, y: number) {
        this.maze[y][x] = 0;
        
        const directions = [
            [0, -2], [2, 0], [0, 2], [-2, 0]
        ];
        
        // Shuffle directions
        for (let i = directions.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [directions[i], directions[j]] = [directions[j], directions[i]];
        }
        
        for (const [dx, dy] of directions) {
            const newX = x + dx;
            const newY = y + dy;
            
            if (newX > 0 && newX < this.mazeWidth - 1 && 
                newY > 0 && newY < this.mazeHeight - 1 && 
                this.maze[newY][newX] === 1) {
                
                this.maze[y + dy/2][x + dx/2] = 0;
                this.generateMazeRecursive(newX, newY);
            }
        }
    }
    
    private createAdditionalPaths() {
        const pathCount = Math.max(1, Math.floor(this.level / 3));
        
        for (let i = 0; i < pathCount; i++) {
            const x = 1 + Math.floor(Math.random() * (this.mazeWidth - 2));
            const y = 1 + Math.floor(Math.random() * (this.mazeHeight - 2));
            
            if (this.maze[y][x] === 1) {
                this.maze[y][x] = 0;
            }
        }
    }
    
    private calculateTileSize() {
        const maxWidth = this.canvas.width - 40;
        const maxHeight = this.canvas.height - 40;
        
        const tileWidth = maxWidth / this.mazeWidth;
        const tileHeight = maxHeight / this.mazeHeight;
        
        this.tileSize = Math.floor(Math.min(tileWidth, tileHeight, 40));
    }
    
    private movePlayer(dx: number, dy: number) {
        if (this.isAnimating || this.paused) return;
        
        const newX = this.player.x + dx;
        const newY = this.player.y + dy;
        
        // Check boundaries and walls
        if (newX >= 0 && newX < this.mazeWidth && 
            newY >= 0 && newY < this.mazeHeight && 
            this.maze[newY][newX] === 0) {
            
            this.player.x = newX;
            this.player.y = newY;
            
            this.startMoveAnimation(dx, dy);
            
            // Check win condition
            if (this.player.x === this.mazeWidth - 2 && this.player.y === this.mazeHeight - 2) {
                this.levelComplete();
            }
        } else {
            // Hit wall - add shake effect
            this.canvas.classList.add('shake');
            setTimeout(() => this.canvas.classList.remove('shake'), 500);
        }
    }
    
    private startMoveAnimation(dx: number, dy: number) {
        this.isAnimating = true;
        this.animationProgress = 0;
        this.playerOffset = { x: -dx * this.tileSize, y: -dy * this.tileSize };
        
        const animate = () => {
            this.animationProgress += 0.3;
            
            if (this.animationProgress >= 1) {
                this.animationProgress = 1;
                this.isAnimating = false;
                this.playerOffset = { x: 0, y: 0 };
            } else {
                requestAnimationFrame(animate);
            }
        };
        
        animate();
    }
    
    private levelComplete() {
        // Add celebration particles
        this.createCelebrationParticles();
        
        // Pulse effect
        this.canvas.classList.add('pulse');
        setTimeout(() => this.canvas.classList.remove('pulse'), 500);
        
        setTimeout(() => {
            if (this.level >= this.maxLevel) {
                this.gameComplete();
            } else {
                this.level++;
                this.startLevel();
            }
        }, 1000);
    }
    
    private createCelebrationParticles() {
        const centerX = (this.player.x + 0.5) * this.tileSize;
        const centerY = (this.player.y + 0.5) * this.tileSize;
        
        for (let i = 0; i < 20; i++) {
            this.particles.push({
                x: centerX,
                y: centerY,
                vx: (Math.random() - 0.5) * 10,
                vy: (Math.random() - 0.5) * 10,
                life: 1,
                color: `hsl(${Math.random() * 360}, 100%, 70%)`
            });
        }
    }
    
    private updateParticles() {
        this.particles = this.particles.filter(particle => {
            particle.x += particle.vx;
            particle.y += particle.vy;
            particle.vy += 0.3; // Gravity
            particle.life -= 0.02;
            
            return particle.life > 0;
        });
    }
    
    private gameComplete() {
        const totalTime = Math.floor((Date.now() - this.gameStartTime) / 1000);
        const gameOverText = document.getElementById("gameOverText");
        const gameOver = document.getElementById("gameOver");
        
        if (gameOverText) {
            gameOverText.textContent = `You completed all ${this.maxLevel} levels in ${totalTime} seconds!`;
        }
        if (gameOver) {
            gameOver.style.display = "block";
        }
    }
    
    private startGame() {
        this.gameStartTime = Date.now();
        this.level = 1;
        this.startLevel();
    }
    
    private startLevel() {
        this.levelStartTime = Date.now();
        this.generateMaze(this.level);
        this.player = { x: 1, y: 1 };
        this.playerOffset = { x: 0, y: 0 };
        this.animationProgress = 0;
        this.isAnimating = false;
        this.particles = [];
        this.paused = false;
        
        this.updateUI();
        
        if (!this.animationId) {
            this.gameLoop();
        }
    }
    
    private resetLevel() {
        this.startLevel();
    }
    
    private restartGame() {
        const gameOver = document.getElementById("gameOver");
        if (gameOver) {
            gameOver.style.display = "none";
        }
        this.startGame();
    }
    
    private togglePause() {
        this.paused = !this.paused;
        const pauseBtn = document.getElementById("pauseBtn");
        if (pauseBtn) {
            pauseBtn.textContent = this.paused ? "Resume" : "Pause";
        }
        
        if (!this.paused && !this.animationId) {
            this.gameLoop();
        }
    }
    
    private toggleFullscreen() {
        if (!document.fullscreenElement) {
            this.canvas.requestFullscreen().catch(err => {
                console.log("Fullscreen not supported:", err);
            });
        } else {
            document.exitFullscreen();
        }
    }
    
    private handleResize() {
        this.calculateTileSize();
    }
    
    private updateUI() {
        const levelDisplay = document.getElementById("levelDisplay");
        const timerDisplay = document.getElementById("timerDisplay");
        
        if (levelDisplay) {
            levelDisplay.textContent = `Level: ${this.level}`;
        }
        
        if (!this.paused && timerDisplay) {
            const currentTime = Math.floor((Date.now() - this.levelStartTime) / 1000);
            timerDisplay.textContent = `Time: ${currentTime}s`;
        }
    }
    
    private drawMaze() {
        const offsetX = (this.canvas.width - this.mazeWidth * this.tileSize) / 2;
        const offsetY = (this.canvas.height - this.mazeHeight * this.tileSize) / 2;
        
        for (let y = 0; y < this.mazeHeight; y++) {
            for (let x = 0; x < this.mazeWidth; x++) {
                const drawX = offsetX + x * this.tileSize;
                const drawY = offsetY + y * this.tileSize;
                
                if (this.maze[y][x] === 1) {
                    // Draw wall with gradient
                    const gradient = this.ctx.createLinearGradient(
                        drawX, drawY, drawX + this.tileSize, drawY + this.tileSize
                    );
                    gradient.addColorStop(0, "#ffffff");
                    gradient.addColorStop(1, "#cccccc");
                    
                    this.ctx.fillStyle = gradient;
                    this.ctx.fillRect(drawX, drawY, this.tileSize, this.tileSize);
                    
                    // Add border
                    this.ctx.strokeStyle = "#999999";
                    this.ctx.lineWidth = 1;
                    this.ctx.strokeRect(drawX, drawY, this.tileSize, this.tileSize);
                }
            }
        }
        
        // Draw goal
        const goalX = offsetX + (this.mazeWidth - 2) * this.tileSize;
        const goalY = offsetY + (this.mazeHeight - 2) * this.tileSize;
        
        const goalGradient = this.ctx.createRadialGradient(
            goalX + this.tileSize/2, goalY + this.tileSize/2, 0,
            goalX + this.tileSize/2, goalY + this.tileSize/2, this.tileSize/2
        );
        goalGradient.addColorStop(0, "#ffff00");
        goalGradient.addColorStop(1, "#ff8800");
        
        this.ctx.fillStyle = goalGradient;
        this.ctx.fillRect(goalX, goalY, this.tileSize, this.tileSize);
        
        // Add sparkle effect to goal
        const time = Date.now() * 0.01;
        this.ctx.fillStyle = `rgba(255, 255, 255, ${0.3 + Math.sin(time) * 0.3})`;
        this.ctx.fillRect(goalX + this.tileSize * 0.2, goalY + this.tileSize * 0.2, 
                         this.tileSize * 0.6, this.tileSize * 0.6);
    }
    
    private drawPlayer() {
        const offsetX = (this.canvas.width - this.mazeWidth * this.tileSize) / 2;
        const offsetY = (this.canvas.height - this.mazeHeight * this.tileSize) / 2;
        
        // Calculate smooth position
        const easedProgress = this.easeInOutQuad(this.animationProgress);
        const currentOffsetX = this.playerOffset.x * (1 - easedProgress);
        const currentOffsetY = this.playerOffset.y * (1 - easedProgress);
        
        const playerX = offsetX + this.player.x * this.tileSize + currentOffsetX;
        const playerY = offsetY + this.player.y * this.tileSize + currentOffsetY;
        
        const playerSize = this.tileSize * this.playerSize;
        const padding = (this.tileSize - playerSize) / 2;
        
        // Draw player with gradient
        const playerGradient = this.ctx.createRadialGradient(
            playerX + this.tileSize/2, playerY + this.tileSize/2, 0,
            playerX + this.tileSize/2, playerY + this.tileSize/2, playerSize/2
        );
        playerGradient.addColorStop(0, "#00ff88");
        playerGradient.addColorStop(1, "#00cc44");
        
        this.ctx.fillStyle = playerGradient;
        this.ctx.fillRect(playerX + padding, playerY + padding, playerSize, playerSize);
        
        // Add highlight
        this.ctx.fillStyle = "rgba(255, 255, 255, 0.3)";
        this.ctx.fillRect(playerX + padding + playerSize * 0.2, 
                         playerY + padding + playerSize * 0.2, 
                         playerSize * 0.3, playerSize * 0.3);
    }
    
    private drawParticles() {
        const offsetX = (this.canvas.width - this.mazeWidth * this.tileSize) / 2;
        const offsetY = (this.canvas.height - this.mazeHeight * this.tileSize) / 2;
        
        this.particles.forEach(particle => {
            this.ctx.save();
            this.ctx.globalAlpha = particle.life;
            this.ctx.fillStyle = particle.color;
            this.ctx.fillRect(offsetX + particle.x - 2, offsetY + particle.y - 2, 4, 4);
            this.ctx.restore();
        });
    }
    
    private easeInOutQuad(t: number): number {
        return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
    }
    
    public gameLoop() {
        if (this.paused) {
            this.animationId = null;
            return;
        }
        
        // Clear canvas
        this.ctx.fillStyle = "#111111";
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Update and draw game elements
        this.updateParticles();
        this.drawMaze();
        this.drawPlayer();
        this.drawParticles();
        
        // Update UI
        this.updateUI();
        
        // Continue loop
        this.animationId = requestAnimationFrame(() => this.gameLoop());
    }
    
    public destroy() {
        if (this.animationId) {
            cancelAnimationFrame(this.animationId);
        }
    }
}

export default function MazeGame() {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const gameRef = useRef<MazeGameEngine | null>(null);

    useEffect(() => {
        if (canvasRef.current && !gameRef.current) {
            gameRef.current = new MazeGameEngine(canvasRef.current);
        }

        return () => {
            if (gameRef.current) {
                gameRef.current.destroy();
                gameRef.current = null;
            }
        };
    }, []);

    return (
        <div className="game-container">
            <h1 className="game-title">Maze Escape+</h1>
            <div className="game-info">
                <span id="levelDisplay">Level: 1</span>
                <span id="timerDisplay">Time: 0s</span>
            </div>
            <canvas 
                ref={canvasRef}
                id="gameCanvas" 
                width="800" 
                height="600"
                className="game-canvas"
            />
            <div className="controls">
                <button id="fullscreenBtn">Go Fullscreen</button>
                <button id="resetBtn">Reset Level</button>
                <button id="pauseBtn">Pause</button>
            </div>
            <div className="instructions">
                <p>Use arrow keys or WASD to move</p>
                <p>Press P to pause, R to reset level, F for fullscreen</p>
                <p>Reach the golden goal to advance to the next level!</p>
            </div>
            <div className="game-over" id="gameOver" style={{ display: 'none' }}>
                <h2>Congratulations!</h2>
                <p id="gameOverText">You completed all levels!</p>
                <button id="playAgainBtn">Play Again</button>
            </div>
        </div>
    );
}