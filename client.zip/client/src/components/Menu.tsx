import { useState, useEffect } from 'react';
import { useGame } from '../lib/stores/useGame';

export default function Menu() {
  const { setGameState } = useGame();
  const [showMenu, setShowMenu] = useState(false);

  useEffect(() => {
    setShowMenu(true);
  }, []);

  const handleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(err => {
        console.log("Fullscreen not supported:", err);
      });
    } else {
      document.exitFullscreen();
    }
  };

  return (
    <div className="menu-container">
      <div className={`menu-content ${showMenu ? 'show' : ''}`}>
        <h1 className="game-title">
          3D MAZE ESCAPE
        </h1>
        <div className="subtitle">
          Survive the monsters and escape the maze!
        </div>
        
        <div className="menu-buttons">
          <button 
            className="menu-btn primary"
            onClick={() => setGameState('levelSelect')}
          >
            PLAY GAME
          </button>
          
          <button 
            className="menu-btn secondary"
            onClick={() => setGameState('howToPlay')}
          >
            HOW TO PLAY
          </button>
          
          <button 
            className="menu-btn secondary"
            onClick={() => setGameState('credits')}
          >
            CREDITS
          </button>
          
          <button 
            className="menu-btn secondary"
            onClick={handleFullscreen}
          >
            FULLSCREEN
          </button>
        </div>
        
        <div className="menu-footer">
          <p>Use WASD to move • Arrow Keys to look around</p>
        </div>
      </div>
      
      {/* Animated background */}
      <div className="menu-bg">
        <div className="bg-grid"></div>
        <div className="bg-particles">
          {Array.from({ length: 20 }).map((_, i) => (
            <div key={i} className="particle" style={{
              '--delay': `${i * 0.5}s`,
              '--x': `${Math.random() * 100}%`,
              '--y': `${Math.random() * 100}%`
            } as React.CSSProperties} />
          ))}
        </div>
      </div>
    </div>
  );
}