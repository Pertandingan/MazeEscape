import { useRef, useState, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface MonsterProps {
  position: [number, number, number];
  targetPosition: [number, number, number];
  maze: number[][];
  frozen?: boolean;
}

export default function Monster({ position, targetPosition, maze, frozen = false }: MonsterProps) {
  const monsterRef = useRef<THREE.Mesh>(null);
  const [currentPosition, setCurrentPosition] = useState<[number, number, number]>(position);
  const [isChasing, setIsChasing] = useState(false);

  useEffect(() => {
    setCurrentPosition(position);
  }, [position]);

  useFrame(() => {
    if (!monsterRef.current || !maze.length) return;

    const [mx, my, mz] = currentPosition;
    const [tx, ty, tz] = targetPosition;

    // Calculate distance to player
    const distance = Math.sqrt(
      Math.pow(tx - mx, 2) + Math.pow(tz - mz, 2)
    );

    // Start chasing if player is within range
    const chaseRange = 8;
    const shouldChase = distance < chaseRange;
    setIsChasing(shouldChase);

    if (shouldChase && distance > 0.5 && !frozen) {
      // Enhanced AI pathfinding with better movement (disabled when frozen)
      const moveSpeed = 0.03;
      let newX = mx;
      let newZ = mz;

      // Calculate direction to player
      const dirX = tx - mx;
      const dirZ = tz - mz;
      const magnitude = Math.sqrt(dirX * dirX + dirZ * dirZ);

      if (magnitude > 0) {
        // Normalize direction and apply speed
        const normalizedX = (dirX / magnitude) * moveSpeed;
        const normalizedZ = (dirZ / magnitude) * moveSpeed;
        
        newX += normalizedX;
        newZ += normalizedZ;

        // Improved collision detection for monsters
        const margin = 0.3;
        const corners = [
          [newX - margin, newZ - margin],
          [newX + margin, newZ - margin],
          [newX - margin, newZ + margin],
          [newX + margin, newZ + margin]
        ];
        
        let canMove = true;
        for (const [x, z] of corners) {
          const gridX = Math.floor(x);
          const gridZ = Math.floor(z);
          if (gridX < 0 || gridX >= maze[0].length || 
              gridZ < 0 || gridZ >= maze.length || 
              maze[gridZ][gridX] === 1) {
            canMove = false;
            break;
          }
        }
        
        if (canMove) {
          setCurrentPosition([newX, 0.5, newZ]); // Keep monsters above ground
        }
      }
    }

    // Update mesh position
    monsterRef.current.position.set(...currentPosition);
    
    // Add menacing floating animation
    monsterRef.current.position.y = currentPosition[1] + Math.sin(Date.now() * 0.008) * 0.2;
    
    // Rotate the monster
    monsterRef.current.rotation.y += 0.02;
  });

  return (
    <group>
      <mesh ref={monsterRef} castShadow>
        <octahedronGeometry args={[0.6]} />
        <meshStandardMaterial 
          color={frozen ? "#4444ff" : (isChasing ? "#ff1111" : "#cc2222")}
          emissive={frozen ? "#001166" : (isChasing ? "#660000" : "#330000")}
          emissiveIntensity={frozen ? 0.6 : (isChasing ? 0.8 : 0.4)}
        />
      </mesh>
      
      {/* Monster glow/aura effect */}
      <mesh position={currentPosition}>
        <sphereGeometry args={[1.0]} />
        <meshBasicMaterial 
          color={isChasing ? "#ff1111" : "#cc4444"}
          transparent 
          opacity={isChasing ? 0.3 : 0.1}
        />
      </mesh>
      
      {/* Eyes */}
      <mesh position={[currentPosition[0] - 0.1, currentPosition[1] + 0.2, currentPosition[2] + 0.3]}>
        <sphereGeometry args={[0.05]} />
        <meshBasicMaterial color="#ffff00" />
      </mesh>
      <mesh position={[currentPosition[0] + 0.1, currentPosition[1] + 0.2, currentPosition[2] + 0.3]}>
        <sphereGeometry args={[0.05]} />
        <meshBasicMaterial color="#ffff00" />
      </mesh>
    </group>
  );
}