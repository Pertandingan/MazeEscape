import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface PlayerProps {
  position: [number, number, number];
  direction: number;
}

export default function Player({ position, direction }: PlayerProps) {
  const playerRef = useRef<THREE.Group>(null);

  useFrame(() => {
    if (playerRef.current) {
      // Update player position and rotation - player feet on ground
      playerRef.current.position.set(position[0], position[1] + 0.8, position[2]);
      playerRef.current.rotation.y = direction;
    }
  });

  return (
    <group ref={playerRef}>
      {/* Player body */}
      <mesh position={[0, 0, 0]}>
        <boxGeometry args={[0.4, 0.8, 0.2]} />
        <meshLambertMaterial color="#00ff00" />
      </mesh>
      
      {/* Player head */}
      <mesh position={[0, 0.5, 0]}>
        <sphereGeometry args={[0.15, 8, 8]} />
        <meshLambertMaterial color="#88ff88" />
      </mesh>
      
      {/* Direction indicator (arrow) */}
      <mesh position={[0, 0.6, 0.2]}>
        <coneGeometry args={[0.05, 0.2, 4]} />
        <meshLambertMaterial color="#ffff00" />
      </mesh>
      
      {/* Arms */}
      <mesh position={[-0.3, 0.1, 0]}>
        <boxGeometry args={[0.1, 0.4, 0.1]} />
        <meshLambertMaterial color="#00cc00" />
      </mesh>
      <mesh position={[0.3, 0.1, 0]}>
        <boxGeometry args={[0.1, 0.4, 0.1]} />
        <meshLambertMaterial color="#00cc00" />
      </mesh>
      
      {/* Legs */}
      <mesh position={[-0.1, -0.5, 0]}>
        <boxGeometry args={[0.1, 0.6, 0.1]} />
        <meshLambertMaterial color="#008800" />
      </mesh>
      <mesh position={[0.1, -0.5, 0]}>
        <boxGeometry args={[0.1, 0.6, 0.1]} />
        <meshLambertMaterial color="#008800" />
      </mesh>
    </group>
  );
}