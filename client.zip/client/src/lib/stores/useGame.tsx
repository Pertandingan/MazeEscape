import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";

export type GameState = "menu" | "levelSelect" | "howToPlay" | "credits" | "playing" | "paused" | "gameOver";

interface GameStore {
  gameState: GameState;
  currentLevel: number;
  score: number;
  time: number;
  freezePowerCooldown: number;
  monstersFrozen: boolean;
  
  // Actions
  setGameState: (state: GameState) => void;
  setCurrentLevel: (level: number) => void;
  setScore: (score: number) => void;
  setTime: (time: number) => void;
  setFreezePowerCooldown: (cooldown: number) => void;
  setMonstersFrozen: (frozen: boolean) => void;
  resetLevel: () => void;
  nextLevel: () => void;
}

export const useGame = create<GameStore>()(
  subscribeWithSelector((set, get) => ({
    gameState: "menu",
    currentLevel: 1,
    score: 0,
    time: 0,
    freezePowerCooldown: 0,
    monstersFrozen: false,
    
    setGameState: (gameState: GameState) => {
      set({ gameState });
    },
    
    setCurrentLevel: (currentLevel: number) => {
      set({ currentLevel });
    },
    
    setScore: (score: number) => {
      set({ score });
    },
    
    setTime: (time: number) => {
      set({ time });
    },
    
    setFreezePowerCooldown: (cooldown: number) => {
      set({ freezePowerCooldown: cooldown });
    },
    
    setMonstersFrozen: (frozen: boolean) => {
      set({ monstersFrozen: frozen });
    },
    
    resetLevel: () => {
      set({ time: 0 });
    },
    
    nextLevel: () => {
      const currentLevel = get().currentLevel;
      set({ 
        currentLevel: currentLevel + 1,
        time: 0 
      });
    }
  }))
);
